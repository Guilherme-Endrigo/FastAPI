from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


# import os
# SQLALCHEMY_DATABASE_URL = f"postgresql://{os.environ['DB_user']}:{os.environ['DB_password']}@{os.environ['DB_host']}/{os.environ['DB_name']}"

SQLALCHEMY_DATABASE_URL = "postgresql://hml_pbl_user:YachieXiesoo3Ait3qua9aec4xeghes@pg-al-publicacoes-hml.ckvdclxowncl.us-east-1.rds.amazonaws.com/pub_hml_2022_02"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()