from sqlalchemy import Column, String
from sqlalchemy.dialects.postgresql import UUID, BOOLEAN, VARCHAR
from database.database import Base

class Taxonomies(Base):
    __tablename__ = 'taxonomies'
    __table_args__ = {u'schema': 'content'}
    taxonomy_id = Column(UUID(as_uuid=True), primary_key=True)
    name = Column(VARCHAR(255))
    slug = Column(VARCHAR(255))
    active = Column(BOOLEAN)

