from pydantic import BaseModel, BaseConfig
from typing import Union
from starlette.responses import Response
from fastapi import Request

class Response_model(BaseModel):
    success: bool
    message: str
    error_message: Union[str, None] = None
    error_code: Union[str, None] = None
    data: Union[dict, None] = None
    request: Request
    response: Response
    status_code: int

    BaseConfig.arbitrary_types_allowed = True

    def __init__(self, success: bool, message: str, data: dict, request: Request, response: Response,status_code: int = 200,error_message: Union[str, None] = None, error_code: Union[str, None] = None):
        response.headers["Access-Control-Allow-Origin"] = request.headers.get("Origin", "https://publicacoes.empiricus.com.br")
        response.headers["Content-type"] = "application/json"
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Headers"] = "authorization,content-type"
        response.headers["Access-Control-Allow-Methods"] = "POST,PUT,GET,OPTIONS,DELETE"
        response.status_code = status_code
        super().__init__(success=success, message=message, data=data,error_message=error_message, error_code=error_code, response=response, request=request, status_code=status_code)

        