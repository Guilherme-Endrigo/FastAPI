import logging

from fastapi import FastAPI, Depends, APIRouter,Request
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import Response

from database.deps import get_session
from models.response import Response_model
from repositories.taxonomy_repository import get_all_taxonomies, get_taxonomy_by_id
# from util.parser import validate_taxonomy_id


origins = ["http://localhost", "https://hml-publicacoes.emprc.info/", "https://publicacoes.emprc.info/", "https://hml-publicacoes.emprc.info/", "https://hml-publicacoes.emprc.info"]

router = APIRouter(prefix='/taxonomy', tags=["taxonomies"])
app = FastAPI(title='Taxonomy API - FastAPI SQL/Alchemy', )
app.include_router(router)
app = FastAPI(middleware=[
    Middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
])


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@app.get('/')
async def get_taxonomies(responses: Response, request: Request, db: Session = Depends(get_session)):
    Taxonomie_result, message = get_all_taxonomies(db)

    response = Response_model(success=message['success'], message=message['message'], data=Taxonomie_result,status_code=message['status_code'], response=responses, request=request)
    return response

    

# @app.get('/{id}')
# async def get_taxonomy(request: Request, id: str, db: Session = Depends(get_session)):
#     try:
#         validate_taxonomy_id(id)

#         taxonomy = get_taxonomy_by_id(db, id)
        
#         if not taxonomy:
#             logger.error(f'Nenhum curso cadastrado para o id: {id}')
#             return make_response(request, status_code=status.HTTP_404_NOT_FOUND, message=f'Nenhum curso cadastrado para o id: {id}.')
            
#         logger.info(f'Retornando os cursos.')
#         return make_response(request, status_code=status.HTTP_200_OK, data=taxonomy)
        
#     except Exception as ex:
#         logger.error(f'{ex}')
#         return make_response(request, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, message=f'{ex}')

if __name__ == '__main__':
    import uvicorn

    uvicorn.run("main:app", host="127.0.0.1", port=8000,
                log_level='info', reload=True)
