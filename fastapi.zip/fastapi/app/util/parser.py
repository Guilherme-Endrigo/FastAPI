import uuid

def check_uuid(id):
    try:
        _ = uuid.UUID(id)
        return True
    except ValueError:
        return False

def validate_taxonomy_id(taxonomy_id):
    if not taxonomy_id:
        return None, {'message': "Deve-se informar um taxonomy_id.", 'status_code': 400}
            
    check_id = check_uuid(taxonomy_id)

    if check_id is False:
        return None, {'message': "Taxonomy_id é inválido.", 'status_code': 400}

