import logging
from sqlalchemy.orm import Session

from models.Taxonomies import Taxonomies
from fastapi import status

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_all_taxonomies(db: Session):
    try:

        logger.info(f'Retornando as taxonomias.')

        logger.info(f'Iniciando busca no banco de dados')
        taxonomies = db.query(Taxonomies).all()
        logger.info(f'Foram encontradas: {len(taxonomies)}.')

        if taxonomies:
            logger.info(f'Retornando as taxonomias.')
            return taxonomies, {'message': "Taxonomias retornadas com sucesso.", 'status_code': status.HTTP_200_OK, 'success': True}
        else:
            logger.error('Nenhuma taxonomia encontrada.')
            return None, {'message': "Nenhuma taxonomia encontrada.", 'status_code': status.HTTP_404_NOT_FOUND, 'success': False}

    except Exception as ex:
        return None, {'message': "Nenhuma taxonomia encontrada.", 'status_code': status.HTTP_500_INTERNAL_SERVER_ERROR, 'success': False}
        
        
# def get_taxonomy_by_id(db: Session, id) -> Taxonomies:
#     db_taxonomy = db.query(Taxonomies).filter(Taxonomies.taxonomy_id == id).one()
#     return db_taxonomy